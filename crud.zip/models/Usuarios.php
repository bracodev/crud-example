<?php
class Usuarios extends Model
{
    public function __construct() {
		parent::__construct( __CLASS__);
    }
}